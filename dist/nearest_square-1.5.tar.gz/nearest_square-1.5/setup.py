from setuptools import setup

setup(name='nearest_square',
      version='1.5',
      description='Nearest Square',
      packages=['nearest_square'],
      author='Rahul Gupta',
      author_email='385.rahul@gmail.com',
      zip_safe=False)
